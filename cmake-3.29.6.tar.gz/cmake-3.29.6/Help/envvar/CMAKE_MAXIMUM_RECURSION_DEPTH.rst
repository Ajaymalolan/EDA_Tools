CMAKE_MAXIMUM_RECURSION_DEPTH
-----------------------------

.. versionadded:: 3.27

.. include:: ENV_VAR.txt

Maximum recursion depth for CMake scripts.  This environment variable is
used if the :variable:`CMAKE_MAXIMUM_RECURSION_DEPTH` variable is not set.
See that variable's documentation for details.
