
EQY License
===========

EQY itself is licensed under the ISC license:

.. literalinclude:: ../../COPYING
   :language: text

Note that the solvers and other components used by EQY come with their
own license terms.

