PIC16F84-T300 benchmark from [trust-hub](https://trust-hub.org/#/benchmarks/chip-level-trojan) (with the obvious bugfix).
