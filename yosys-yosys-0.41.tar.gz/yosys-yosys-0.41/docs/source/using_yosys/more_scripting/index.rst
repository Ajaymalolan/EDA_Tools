More scripting
--------------

.. todo:: brief overview for the more scripting index

.. toctree::
   :maxdepth: 3

   load_design
   selections
   interactive_investigation
   model_checking

.. troubleshooting
