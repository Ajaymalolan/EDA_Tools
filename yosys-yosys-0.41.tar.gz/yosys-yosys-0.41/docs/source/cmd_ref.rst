.. _cmd_ref:

================================================================================
Command line reference
================================================================================

.. literalinclude:: /generated/yosys
    :start-at: Usage

.. toctree::
	:caption: Command reference
	:maxdepth: 1
	:glob:

	/appendix/env_vars
	/cmd/*
