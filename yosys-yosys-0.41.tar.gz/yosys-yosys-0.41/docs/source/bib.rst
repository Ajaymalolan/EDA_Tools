.. only:: html

	Literature references
	=====================

	.. rubric:: Bibliography

.. bibliography:: literature.bib

.. todo:: see if we can get the two hanging appnotes as lit references
