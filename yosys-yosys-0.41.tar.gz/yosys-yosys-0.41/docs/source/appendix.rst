Appendix
========

.. toctree::
	:maxdepth: 2
	:includehidden:

	appendix/primer
	appendix/auxlibs
	appendix/auxprogs

	bib

.. toctree::
	:maxdepth: 1
	:includehidden:

	cmd_ref
